TWITTER_ACCESS_TOKEN = "########-##############"
TWITTER_ACCESS_TOKEN_SECRET = "##########"
TWITTER_CONSUMER_KEY = "##########"
TWITTER_CONSUMER_SECRET = "##########"

ALPACA_ENDPOINT_URL = "https://paper-api.alpaca.markets"
ALPACA_API_KEY = "##########"
ALPACA_SECRET_KEY = "##########"

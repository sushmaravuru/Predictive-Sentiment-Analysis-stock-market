# How to set up a virtual enviornment that runs python3.8
virtualenv venv -p "C:\Python38\python.exe"
source venv/Scripts/activate
pip install -r requirements.txt